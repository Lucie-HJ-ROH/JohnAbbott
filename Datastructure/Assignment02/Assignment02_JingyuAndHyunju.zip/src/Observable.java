import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public abstract class Observable {
    private List<Observer> observers = new ArrayList<Observer>(); // keep observer
    public void addObserver(Observer observer) {
        observers.add(observer);
    }
    public void deleteObserver(Observer observer) {
        observers.remove(observer);
    }
    public void notifyObservers() {
        Iterator<Observer> it = observers.iterator();
        while(it.hasNext()) {
            Observer o = it.next();
            o.update(this);
        }
    }

    public abstract String getLastTweet();
    public abstract void tweet(String message);


}
