package Question01;

public interface Collectible {
   void pickup();
   void drop();
}