package Activity24th;

public class AnimalTest {
    public static void main(String[] args) {
        Animal cow = new Cow();
        Animal dog = new Dog();
        Animal duck = new Duck();

        System.out.println(dog);
        System.out.println(cow);
        System.out.println(duck);

    }
}
