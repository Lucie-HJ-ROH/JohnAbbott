package assignment01;
/**
 * Assignment01
 * Hyunju Roh
 * Written by : Hyunju Roh 2227572
 */
public class ComputerStoreMain {
    public static void main(String[] args) {
        System.out.println("\n===============Welcome to my computer store================\n");
        ComputerStore store = new ComputerStore();
        store.tryMainMenuOption();
    }
}
